const express = require('express');
const app = express();
const cors = require('cors');
const empleadosRoutes = require('./routes/empleados');

app.use(cors());
app.use(express.json());
//La ruta base /api/empleados se configura explícitamente  
//Todo lo que esté en el archivo routes/empleados.js se va a usar bajo la ruta /api/empleados
app.use('/api/empleados', empleadosRoutes);

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
});